const { Kafka } = require('kafkajs');
const nodemailer = require('nodemailer');

const kafka = new Kafka({
  clientId: 'notification-service',
  brokers: [process.env.KAFKA_BROKER || 'kafka:9092'],
});

const consumer = kafka.consumer({ groupId: 'notification-group' });

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

async function sendEmail(to, subject, text) {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to,
      subject,
      text,
    });
    console.log(`Email sent to ${to}`);
  } catch (err) {
    console.error('Email error:', err.message);
  }
}

async function startConsumer() {
  await consumer.connect();
  console.log('Kafka consumer connected');

  await consumer.subscribe({ topic: 'user-events', fromBeginning: false });
  await consumer.subscribe({ topic: 'job-events', fromBeginning: false });

  await consumer.run({
    eachMessage: async ({ topic, message }) => {
      const data = JSON.parse(message.value.toString());

      if (topic === 'user-events' && data.event === 'user-registered') {
        console.log('');
        console.log('====================================');
        console.log('  NEW USER REGISTERED');
        console.log('====================================');
        console.log(`  Name    : ${data.name}`);
        console.log(`  Email   : ${data.email}`);
        console.log(`  User ID : ${data.userId}`);
        console.log(`  Time    : ${data.timestamp}`);
        console.log('  Action  : Welcome email sent!');
        console.log('====================================');
        console.log('');

        await sendEmail(
          data.email,
          'Welcome to Job Board!',
          `Hi ${data.name},\n\nWelcome to Job Board! Your account has been created successfully.\n\nBest regards,\nJob Board Team`
        );
      }

      if (topic === 'job-events' && data.event === 'job-applied') {
        console.log('');
        console.log('====================================');
        console.log('  NEW JOB APPLICATION');
        console.log('====================================');
        console.log(`  Job     : ${data.jobTitle}`);
        console.log(`  Company : ${data.company}`);
        console.log(`  From    : ${data.userEmail}`);
        console.log(`  User ID : ${data.userId}`);
        console.log(`  Time    : ${data.timestamp}`);
        console.log('  Action  : Company notified!');
        console.log('====================================');
        console.log('');

        await sendEmail(
          data.userEmail,
          `Application Received - ${data.jobTitle}`,
          `Hi,\n\nYour application for ${data.jobTitle} at ${data.company} has been received successfully.\n\nBest regards,\nJob Board Team`
        );
      }
    },
  });
}

module.exports = { startConsumer };