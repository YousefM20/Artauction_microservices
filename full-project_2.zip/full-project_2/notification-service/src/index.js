require('dotenv').config();
const { startConsumer } = require('./kafka/consumer');

console.log('Notification Service starting...');

startConsumer().catch((err) => {
  console.error('Notification Service failed to start:', err.message);
  process.exit(1);
});
