const express = require('express');
const router = express.Router();
const { createJob, getAllJobs, getJobById, applyForJob } = require('../controllers/job.controller');
const { verifyToken } = require('../middleware/auth.middleware');

// Public
router.get('/', getAllJobs);
router.get('/:id', getJobById);

// Protected (need JWT token)
router.post('/', verifyToken, createJob);
router.post('/:id/apply', verifyToken, applyForJob);

module.exports = router;
