require('dotenv').config();
const express = require('express');
const jobRoutes = require('./routes/job.routes');
const { connectDB } = require('./models/db');
const { connectKafka } = require('./kafka/producer');

const app = express();
app.use(express.json());

// Routes
app.use('/api/jobs', jobRoutes);

// Health check
app.get('/health', (req, res) => res.json({ status: 'Job Service is running' }));

const PORT = process.env.PORT || 3002;

async function start() {
  await connectDB();
  await connectKafka();
  app.listen(PORT, () => {
    console.log(`Job Service running on port ${PORT}`);
  });
}

start();
