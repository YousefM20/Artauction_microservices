const { Kafka } = require('kafkajs');

const kafka = new Kafka({
  clientId: 'job-service',
  brokers: [process.env.KAFKA_BROKER || 'kafka:9092'],
});

const producer = kafka.producer();

async function connectKafka() {
  await producer.connect();
  console.log('Kafka producer connected');
}

async function publishJobApplied(data) {
  await producer.send({
    topic: 'job-events',
    messages: [
      {
        key: String(data.jobId),
        value: JSON.stringify({
          event: 'job-applied',
          jobId: data.jobId,
          jobTitle: data.jobTitle,
          company: data.company,
          userId: data.userId,
          userEmail: data.userEmail,
          timestamp: new Date().toISOString(),
        }),
      },
    ],
  });
  console.log(`Event published: job-applied for job ${data.jobId} by user ${data.userId}`);
}

module.exports = { connectKafka, publishJobApplied };
