const { pool } = require('../models/db');
const { publishJobApplied } = require('../kafka/producer');

// POST /api/jobs — create a job
async function createJob(req, res) {
  const { title, company, description } = req.body;
  const userId = req.user.userId;

  if (!title || !company) {
    return res.status(400).json({ error: 'title and company are required' });
  }

  try {
    const result = await pool.query(
      'INSERT INTO jobs (title, company, description, posted_by) VALUES ($1, $2, $3, $4) RETURNING *',
      [title, company, description, userId]
    );

    return res.status(201).json({
      message: 'Job created successfully',
      job: result.rows[0],
    });
  } catch (err) {
    console.error('Create job error:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

// GET /api/jobs — list all jobs
async function getAllJobs(req, res) {
  try {
    const result = await pool.query('SELECT * FROM jobs ORDER BY created_at DESC');
    return res.json({ jobs: result.rows });
  } catch (err) {
    console.error('Get jobs error:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

// GET /api/jobs/:id — get one job
async function getJobById(req, res) {
  const { id } = req.params;

  try {
    const result = await pool.query('SELECT * FROM jobs WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Job not found' });
    }

    return res.json({ job: result.rows[0] });
  } catch (err) {
    console.error('Get job error:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

// POST /api/jobs/:id/apply — apply for a job
async function applyForJob(req, res) {
  const { id } = req.params;
  const userId = req.user.userId;
  const userEmail = req.user.email;

  try {
    // Check job exists
    const jobResult = await pool.query('SELECT * FROM jobs WHERE id = $1', [id]);
    if (jobResult.rows.length === 0) {
      return res.status(404).json({ error: 'Job not found' });
    }

    const job = jobResult.rows[0];

    // Check if already applied
    const existing = await pool.query(
      'SELECT id FROM applications WHERE job_id = $1 AND user_id = $2',
      [id, userId]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'You already applied for this job' });
    }

    // Save application
    await pool.query(
      'INSERT INTO applications (job_id, user_id, user_email) VALUES ($1, $2, $3)',
      [id, userId, userEmail]
    );

    // Publish Kafka event
    await publishJobApplied({
      jobId: job.id,
      jobTitle: job.title,
      company: job.company,
      userId,
      userEmail,
    });

    return res.status(201).json({
      message: `Successfully applied for ${job.title} at ${job.company}`,
    });
  } catch (err) {
    console.error('Apply job error:', err.message);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

module.exports = { createJob, getAllJobs, getJobById, applyForJob };
