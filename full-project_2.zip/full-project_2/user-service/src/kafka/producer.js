const { Kafka } = require('kafkajs');

const kafka = new Kafka({
  clientId: 'user-service',
  brokers: [process.env.KAFKA_BROKER || 'kafka:9092'],
});

const producer = kafka.producer();

async function connectKafka() {
  await producer.connect();
  console.log('Kafka producer connected');
}

async function publishUserRegistered(user) {
  await producer.send({
    topic: 'user-events',
    messages: [
      {
        key: String(user.id),
        value: JSON.stringify({
          event: 'user-registered',
          userId: user.id,
          name: user.name,
          email: user.email,
          timestamp: new Date().toISOString(),
        }),
      },
    ],
  });
  console.log(`Event published: user-registered for ${user.email}`);
}

module.exports = { connectKafka, publishUserRegistered };
