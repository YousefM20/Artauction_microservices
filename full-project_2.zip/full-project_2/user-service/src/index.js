require('dotenv').config();
const express = require('express');
const authRoutes = require('./routes/auth.routes');
const { connectDB } = require('./models/db');
const { connectKafka } = require('./kafka/producer');

const app = express();
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);

// Health check
app.get('/health', (req, res) => res.json({ status: 'User Service is running' }));

const PORT = process.env.PORT || 3001;

async function start() {
  await connectDB();
  await connectKafka();
  app.listen(PORT, () => {
    console.log(`User Service running on port ${PORT}`);
  });
}

start();
